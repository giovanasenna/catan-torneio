import React, { useState, useEffect } from 'react';
import { X, Trophy, AlertCircle, Sparkles, UserPlus, Trash2, Plus, Minus } from 'lucide-react';
import { Match, MatchPlayerResult, Season } from '../types';
import { CURRENT_SEASON, OFFICIAL_PLAYERS, SCENARIOS, SEASONS } from '../constants';
import { calculateBalancedVPPercent, calculateNormalizedVP } from '../utils/calculations';

interface MatchFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (match: Match) => void;
  matchToEdit?: Match | null;
}

interface ActivePlayerState {
  id: string;
  name: string;
  isOfficial: boolean;
  colorHex: string;
  selected: boolean;
  vp: number;
}

export const MatchFormModal: React.FC<MatchFormModalProps> = ({
  isOpen,
  onClose,
  onSave,
  matchToEdit,
}) => {
  const [date, setDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [season, setSeason] = useState<Season>(CURRENT_SEASON);
  const [scenarioId, setScenarioId] = useState<string>('base');
  const [targetVP, setTargetVP] = useState<number>(10);
  const [is5to6Players, setIs5to6Players] = useState<boolean>(false);
  const [notes, setNotes] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState<string>('');

  // Players state
  const [players, setPlayers] = useState<ActivePlayerState[]>([]);
  const [newVisitorName, setNewVisitorName] = useState<string>('');
  const [visitorColor, setVisitorColor] = useState<string>('#8B5CF6'); // Purple default

  // Initialize or reset form when modal opens or edit match changes
  useEffect(() => {
    if (matchToEdit) {
      setDate(matchToEdit.date);
      setSeason(matchToEdit.season);
      setScenarioId(matchToEdit.scenarioId);
      setTargetVP(matchToEdit.targetVP);
      setIs5to6Players(matchToEdit.is5to6Players);
      setNotes(matchToEdit.notes || '');

      const initialPlayers: ActivePlayerState[] = OFFICIAL_PLAYERS.map(op => {
        const found = matchToEdit.playerResults.find(r => r.playerId === op.id);
        return {
          id: op.id,
          name: op.name,
          isOfficial: true,
          colorHex: op.colorHex,
          selected: !!found,
          vp: found ? found.vp : 8,
        };
      });

      for (const res of matchToEdit.playerResults) {
        if (!res.isOfficial) {
          initialPlayers.push({
            id: res.playerId,
            name: res.playerName,
            isOfficial: false,
            colorHex: res.playerColorHex || '#8B5CF6',
            selected: true,
            vp: res.vp,
          });
        }
      }
      setPlayers(initialPlayers);
    } else {
      setDate(new Date().toISOString().split('T')[0]);
      setSeason(CURRENT_SEASON);
      setScenarioId('base');
      setTargetVP(10);
      setIs5to6Players(false);
      setNotes('');

      setPlayers(
        OFFICIAL_PLAYERS.map(op => ({
          id: op.id,
          name: op.name,
          isOfficial: true,
          colorHex: op.colorHex,
          selected: true,
          vp: 8,
        }))
      );
    }
    setErrorMessage('');
  }, [isOpen, matchToEdit]);

  const handleScenarioChange = (newScenarioId: string) => {
    setScenarioId(newScenarioId);
    const scen = SCENARIOS.find(s => s.id === newScenarioId);
    if (scen) {
      setTargetVP(scen.defaultVP);
    }
  };

  const handleTogglePlayer = (id: string) => {
    setPlayers(prev =>
      prev.map(p => (p.id === id ? { ...p, selected: !p.selected } : p))
    );
  };

  const handleVPChange = (id: string, vpVal: number) => {
    setPlayers(prev =>
      prev.map(p => (p.id === id ? { ...p, vp: Math.max(0, vpVal) } : p))
    );
  };

  const handleAdjustVP = (id: string, delta: number) => {
    setPlayers(prev =>
      prev.map(p => (p.id === id ? { ...p, vp: Math.max(0, p.vp + delta) } : p))
    );
  };

  const handleAddVisitor = () => {
    const clean = newVisitorName.trim();
    if (!clean) return;

    const visitorId = `visitor-${Date.now()}`;
    const newVisitor: ActivePlayerState = {
      id: visitorId,
      name: `${clean} (Visitante)`,
      isOfficial: false,
      colorHex: visitorColor,
      selected: true,
      vp: 6,
    };

    setPlayers(prev => [...prev, newVisitor]);
    setNewVisitorName('');
  };

  const handleRemoveVisitor = (id: string) => {
    setPlayers(prev => prev.filter(p => p.id !== id));
  };

  if (!isOpen) return null;

  const activeParticipants = players.filter(p => p.selected);
  const numPlayers = activeParticipants.length;
  const totalTableVP = activeParticipants.reduce((sum, p) => sum + p.vp, 0);
  const maxVP = activeParticipants.length > 0 ? Math.max(...activeParticipants.map(p => p.vp)) : 0;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (numPlayers < 3 || numPlayers > 6) {
      setErrorMessage(`Uma partida de Catan deve conter de 3 a 6 participantes (selecionados: ${numPlayers}).`);
      return;
    }

    if (targetVP <= 0) {
      setErrorMessage('A meta de PV deve ser maior que zero.');
      return;
    }

    const winners = activeParticipants.filter(p => p.vp === maxVP);
    const winner = winners[0];

    const playerResults: MatchPlayerResult[] = activeParticipants.map(p => {
      const normalizedVP = calculateNormalizedVP(p.vp, targetVP);
      const balancedVPPercent = calculateBalancedVPPercent(p.vp, totalTableVP, numPlayers);
      return {
        playerId: p.id,
        playerName: p.name,
        isOfficial: p.isOfficial,
        playerColorHex: p.colorHex,
        vp: p.vp,
        normalizedVP,
        balancedVPPercent,
        isWinner: p.vp === maxVP,
      };
    });

    const currentScenario = SCENARIOS.find(s => s.id === scenarioId);

    const savedMatch: Match = {
      id: matchToEdit ? matchToEdit.id : `match-${Date.now()}`,
      date,
      season,
      scenarioId,
      scenarioName: currentScenario ? currentScenario.name : 'Personalizado',
      targetVP,
      notes: notes.trim(),
      is5to6Players: is5to6Players || numPlayers > 4,
      playerResults,
      winnerId: winner.id,
      winnerName: winner.name,
      createdAt: matchToEdit ? matchToEdit.createdAt : new Date().toISOString(),
    };

    onSave(savedMatch);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-0 sm:p-4 bg-stone-950/80 backdrop-blur-sm overflow-y-auto">
      {/* Modal / Native Mobile Fullscreen Container */}
      <div className="bg-stone-900 border-0 sm:border sm:border-stone-800 rounded-none sm:rounded-2xl w-full max-w-2xl text-stone-100 shadow-2xl h-full sm:h-auto sm:max-h-[92vh] flex flex-col">
        {/* Modal Top Bar */}
        <div className="px-5 py-4 border-b border-stone-800 flex items-center justify-between shrink-0 bg-stone-900 sticky top-0 z-10">
          <div className="flex items-center gap-2">
            <Trophy className="text-amber-400" size={22} />
            <h2 className="text-base sm:text-lg font-bold font-serif text-amber-100">
              {matchToEdit ? 'Editar Partida' : 'Registrar Nova Partida'}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg text-stone-400 hover:text-stone-200 hover:bg-stone-800 transition-colors min-h-[44px] min-w-[44px] flex items-center justify-center"
          >
            <X size={20} />
          </button>
        </div>

        {/* Modal Form Content */}
        <form onSubmit={handleSubmit} className="p-4 sm:p-6 overflow-y-auto space-y-5 flex-1">
          {errorMessage && (
            <div className="p-3 bg-red-950/80 border border-red-800 text-red-200 rounded-xl text-xs sm:text-sm flex items-start gap-2">
              <AlertCircle size={18} className="shrink-0 mt-0.5" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Row 1: Date & Season */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
            <div>
              <label className="block text-xs font-semibold text-stone-400 mb-1 uppercase tracking-wide">
                Data da Partida
              </label>
              <input
                type="date"
                value={date}
                onChange={e => setDate(e.target.value)}
                required
                className="w-full bg-stone-950 border border-stone-700 rounded-xl px-3 py-2.5 text-stone-200 text-sm focus:border-amber-400 focus:outline-none min-h-[44px]"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-stone-400 mb-1 uppercase tracking-wide">
                Estação do Torneio
              </label>
              <select
                value={season}
                onChange={e => setSeason(e.target.value as Season)}
                className="w-full bg-stone-950 border border-stone-700 rounded-xl px-3 py-2.5 text-stone-200 text-sm focus:border-amber-400 focus:outline-none min-h-[44px]"
              >
                {SEASONS.map(s => (
                  <option key={s} value={s}>
                    {s} {s === 'Primavera' ? '(Estação Atual)' : ''}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Row 2: Scenario and Target VP */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 sm:gap-4">
            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-stone-400 mb-1 uppercase tracking-wide">
                Modo de Jogo / Cenário
              </label>
              <select
                value={scenarioId}
                onChange={e => handleScenarioChange(e.target.value)}
                className="w-full bg-stone-950 border border-stone-700 rounded-xl px-3 py-2.5 text-stone-200 text-sm focus:border-amber-400 focus:outline-none min-h-[44px]"
              >
                <optgroup label="Catan Clássico">
                  <option value="base">Catan Jogo Base (Meta: 10 PV)</option>
                </optgroup>
                <optgroup label="Catan Navegantes (Cenários 1 a 9)">
                  {SCENARIOS.filter(s => s.category === 'Navegantes').map(s => (
                    <option key={s.id} value={s.id}>
                      {s.name} ({s.defaultVP} PV)
                    </option>
                  ))}
                </optgroup>
                <optgroup label="Outro">
                  <option value="custom">Personalizado</option>
                </optgroup>
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-stone-400 mb-1 uppercase tracking-wide">
                Meta de PV
              </label>
              <input
                type="number"
                min={8}
                max={30}
                value={targetVP}
                onChange={e => setTargetVP(parseInt(e.target.value, 10) || 10)}
                required
                className="w-full bg-stone-950 border border-stone-700 rounded-xl px-3 py-2.5 text-stone-200 text-sm focus:border-amber-400 focus:outline-none font-mono min-h-[44px]"
              />
            </div>
          </div>

          {/* Expansion toggle */}
          <div className="flex items-center justify-between p-3.5 bg-stone-950/60 border border-stone-800 rounded-xl">
            <div className="text-xs text-stone-300 pr-2">
              <span className="font-semibold block text-stone-200">Expansão 5-6 Jogadores</span>
              Habilita regras de mapa expandido.
            </div>
            <label className="relative inline-flex items-center cursor-pointer min-h-[44px] min-w-[44px] justify-center">
              <input
                type="checkbox"
                checked={is5to6Players}
                onChange={e => setIs5to6Players(e.target.checked)}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-stone-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[12px] after:left-[4px] after:bg-stone-300 after:border-stone-400 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-amber-500"></div>
            </label>
          </div>

          {/* Section: Players Selection */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label className="block text-xs font-semibold text-stone-400 uppercase tracking-wide">
                Jogadores na Mesa ({numPlayers}/6)
              </label>
              <span className="text-[11px] text-amber-400 font-medium">
                Toque para ativar/desativar
              </span>
            </div>

            {/* Official Players Checklist */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {players.filter(p => p.isOfficial).map(p => {
                const isSelected = p.selected;
                return (
                  <button
                    type="button"
                    key={p.id}
                    onClick={() => handleTogglePlayer(p.id)}
                    className={`p-3 rounded-xl border text-left transition-all flex items-center gap-2.5 min-h-[48px] ${
                      isSelected
                        ? 'border-amber-400 bg-stone-800/90 shadow-sm'
                        : 'border-stone-800 bg-stone-950/40 text-stone-500 hover:border-stone-700'
                    }`}
                  >
                    <div
                      className="w-4 h-4 rounded-full border border-stone-400/50 shrink-0"
                      style={{ backgroundColor: p.colorHex }}
                    />
                    <div className="truncate text-xs font-semibold text-stone-200">
                      {p.name}
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Visitors area */}
            <div className="p-3.5 bg-stone-950/50 border border-stone-800 rounded-xl space-y-2.5">
              <div className="flex items-center gap-2 text-xs font-medium text-stone-300">
                <UserPlus size={15} className="text-amber-400" />
                <span>Adicionar Visitante / Convidado</span>
              </div>
              <div className="flex flex-col sm:flex-row gap-2">
                <input
                  type="text"
                  placeholder="Nome do convidado (ex: Carlos)"
                  value={newVisitorName}
                  onChange={e => setNewVisitorName(e.target.value)}
                  className="flex-1 bg-stone-900 border border-stone-700 rounded-xl px-3 py-2 text-xs text-stone-200 placeholder-stone-500 focus:outline-none focus:border-amber-400 min-h-[44px]"
                />
                <div className="flex gap-2">
                  <select
                    value={visitorColor}
                    onChange={e => setVisitorColor(e.target.value)}
                    className="bg-stone-900 border border-stone-700 rounded-xl px-2 py-2 text-xs text-stone-200 min-h-[44px]"
                  >
                    <option value="#8B5CF6">Roxo</option>
                    <option value="#10B981">Verde</option>
                    <option value="#F97316">Laranja</option>
                    <option value="#06B6D4">Ciano</option>
                    <option value="#EC4899">Rosa</option>
                  </select>
                  <button
                    type="button"
                    onClick={handleAddVisitor}
                    className="px-4 py-2 text-xs font-medium bg-stone-800 hover:bg-stone-700 text-stone-200 rounded-xl transition-colors min-h-[44px]"
                  >
                    Adicionar
                  </button>
                </div>
              </div>

              {/* Added visitors list */}
              {players.filter(p => !p.isOfficial).length > 0 && (
                <div className="flex flex-wrap gap-2 pt-1">
                  {players.filter(p => !p.isOfficial).map(v => (
                    <div
                      key={v.id}
                      className="flex items-center gap-2 bg-stone-900 border border-stone-700 px-3 py-1.5 rounded-xl text-xs"
                    >
                      <div
                        className="w-3 h-3 rounded-full shrink-0"
                        style={{ backgroundColor: v.colorHex }}
                      />
                      <span className="text-stone-200">{v.name}</span>
                      <button
                        type="button"
                        onClick={() => handleRemoveVisitor(v.id)}
                        className="text-stone-500 hover:text-red-400 ml-1 p-1 min-h-[32px] min-w-[32px] flex items-center justify-center"
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Section: PV inputs with MOBILE-OPTIMIZED STEPPERS */}
          {activeParticipants.length > 0 && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <label className="block text-xs font-semibold text-stone-400 uppercase tracking-wide">
                  Pontos de Vitória (PV)
                </label>
                <span className="text-[11px] text-amber-400 font-medium flex items-center gap-1">
                  <Sparkles size={12} />
                  Use [-] e [+] para ajustar
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {activeParticipants.map(p => {
                  const isCurrentWinner = p.vp === maxVP && maxVP > 0;
                  const normalized = calculateNormalizedVP(p.vp, targetVP);
                  const balancedVP = calculateBalancedVPPercent(p.vp, totalTableVP, numPlayers);

                  return (
                    <div
                      key={p.id}
                      className={`p-3.5 rounded-2xl border transition-all ${
                        isCurrentWinner
                          ? 'border-amber-400/90 bg-amber-950/30 shadow-md'
                          : 'border-stone-800 bg-stone-950/70'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-2.5">
                        <div className="flex items-center gap-2 min-w-0">
                          <div
                            className="w-4 h-4 rounded-full shrink-0 border border-stone-400/50"
                            style={{ backgroundColor: p.colorHex }}
                          />
                          <span className="text-sm font-bold text-stone-100 truncate font-serif">
                            {p.name}
                          </span>
                        </div>
                        {isCurrentWinner && (
                          <span className="flex items-center gap-1 text-[11px] font-bold text-amber-400 bg-amber-950/80 border border-amber-800 px-2 py-0.5 rounded-lg">
                            🏆 Vencedor
                          </span>
                        )}
                      </div>

                      {/* Stepper controls with generous touch targets */}
                      <div className="flex items-center gap-2">
                        {/* Decrement Button */}
                        <button
                          type="button"
                          onClick={() => handleAdjustVP(p.id, -1)}
                          className="w-11 h-11 rounded-xl bg-stone-800 hover:bg-stone-700 active:scale-95 text-stone-200 flex items-center justify-center font-bold text-lg border border-stone-700 shrink-0 transition-transform"
                        >
                          <Minus size={18} />
                        </button>

                        {/* Direct input */}
                        <input
                          type="number"
                          min={0}
                          max={30}
                          value={p.vp}
                          onChange={e => handleVPChange(p.id, parseInt(e.target.value, 10) || 0)}
                          className="w-16 h-11 text-center text-xl font-bold font-mono bg-stone-900 border border-stone-700 rounded-xl text-stone-100 focus:border-amber-400 focus:outline-none"
                        />

                        {/* Increment Button */}
                        <button
                          type="button"
                          onClick={() => handleAdjustVP(p.id, 1)}
                          className="w-11 h-11 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 active:scale-95 text-amber-300 flex items-center justify-center font-bold text-lg border border-amber-500/40 shrink-0 transition-transform"
                        >
                          <Plus size={18} />
                        </button>

                        {/* Live calculated fairness metrics */}
                        <div className="flex-1 text-[11px] text-stone-400 pl-2 space-y-0.5">
                          <div className="flex justify-between">
                            <span>Norm:</span>
                            <span className="font-mono text-stone-200">{normalized.toFixed(2)}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>VP%:</span>
                            <span className="font-mono text-amber-300 font-bold">{balancedVP}%</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Match Notes */}
          <div>
            <label className="block text-xs font-semibold text-stone-400 mb-1 uppercase tracking-wide">
              Observações da Partida (Opcional)
            </label>
            <textarea
              rows={2}
              placeholder="Ex: Disputa por Maior Estrada, exército, momentos marcantes..."
              value={notes}
              onChange={e => setNotes(e.target.value)}
              className="w-full bg-stone-950 border border-stone-700 rounded-xl px-3 py-2 text-stone-200 text-xs sm:text-sm focus:border-amber-400 focus:outline-none"
            />
          </div>

          {/* Bottom Action CTA */}
          <div className="sticky bottom-0 bg-stone-900 pt-3 pb-2 border-t border-stone-800 flex items-center justify-end gap-3 shrink-0">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-3 text-xs sm:text-sm font-medium text-stone-300 hover:text-stone-100 rounded-xl transition-colors min-h-[44px]"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="flex-1 sm:flex-none px-6 py-3 text-xs sm:text-sm font-bold text-stone-950 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 active:scale-[0.98] rounded-xl shadow-md transition-all min-h-[44px] flex items-center justify-center gap-1.5"
            >
              <span>{matchToEdit ? 'Atualizar Partida' : 'Salvar Partida no Torneio'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
