import React, { useState } from 'react';
import { History, Search, Filter, Edit, Trash2, Calendar, Trophy, Users, AlertTriangle } from 'lucide-react';
import { Match, Season } from '../types';
import { SEASONS } from '../constants';

interface MatchHistoryTabProps {
  matches: Match[];
  onEditMatch: (match: Match) => void;
  onDeleteMatch: (matchId: string) => void;
  onOpenNewMatch: () => void;
}

export const MatchHistoryTab: React.FC<MatchHistoryTabProps> = ({
  matches,
  onEditMatch,
  onDeleteMatch,
  onOpenNewMatch,
}) => {
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [seasonFilter, setSeasonFilter] = useState<Season | 'all'>('all');
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);

  // Filter matches
  const filteredMatches = matches.filter(m => {
    if (seasonFilter !== 'all' && m.season !== seasonFilter) {
      return false;
    }
    if (searchTerm.trim()) {
      const term = searchTerm.toLowerCase();
      const matchInScenario = m.scenarioName.toLowerCase().includes(term);
      const matchInWinner = m.winnerName.toLowerCase().includes(term);
      const matchInNotes = (m.notes || '').toLowerCase().includes(term);
      const matchInPlayers = m.playerResults.some(p => p.playerName.toLowerCase().includes(term));
      if (!matchInScenario && !matchInWinner && !matchInNotes && !matchInPlayers) {
        return false;
      }
    }
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Header and Filter Bar */}
      <div className="bg-stone-900 border border-stone-800 p-5 rounded-2xl flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <History className="text-amber-400" size={22} />
            <h1 className="text-xl sm:text-2xl font-bold font-serif text-amber-100">
              Histórico de Partidas
            </h1>
          </div>
          <p className="text-xs sm:text-sm text-stone-400 mt-1">
            {matches.length} partidas registradas no torneio.
          </p>
        </div>

        {/* Search & Season Dropdown */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
          <div className="relative">
            <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-stone-500" />
            <input
              type="text"
              placeholder="Buscar cenário, jogador..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="bg-stone-950 border border-stone-700 rounded-lg pl-9 pr-3 py-1.5 text-xs text-stone-200 placeholder-stone-500 focus:outline-none focus:border-amber-400 w-full sm:w-56"
            />
          </div>

          <select
            value={seasonFilter}
            onChange={e => setSeasonFilter(e.target.value as Season | 'all')}
            className="bg-stone-950 border border-stone-700 rounded-lg px-3 py-1.5 text-xs text-stone-200 focus:outline-none focus:border-amber-400"
          >
            <option value="all">Todas as Estações</option>
            {SEASONS.map(s => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Match Cards List */}
      {filteredMatches.length === 0 ? (
        <div className="bg-stone-900 border border-stone-800 rounded-2xl p-8 text-center text-stone-400 space-y-3">
          <p>Nenhuma partida encontrada para esta busca.</p>
          <button
            onClick={onOpenNewMatch}
            className="px-4 py-2 text-xs font-semibold bg-amber-400 text-stone-950 rounded-lg hover:bg-amber-300 transition-colors"
          >
            Registrar Nova Partida
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredMatches.map(match => {
            const isDeleting = confirmDeleteId === match.id;

            return (
              <div
                key={match.id}
                className="bg-stone-900 border border-stone-800 rounded-2xl p-5 shadow-sm space-y-4 transition-all hover:border-stone-700"
              >
                {/* Match Card Top Row */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-stone-800/80 pb-3">
                  <div className="flex items-center gap-3 flex-wrap">
                    <span className="font-bold text-base text-stone-100 font-serif">
                      {match.scenarioName}
                    </span>
                    <span className="text-xs px-2.5 py-0.5 rounded-full bg-amber-950/70 border border-amber-800/80 text-amber-300 font-medium">
                      {match.season}
                    </span>
                    <span className="text-xs text-stone-400 flex items-center gap-1 font-mono">
                      <Calendar size={13} />
                      {match.date}
                    </span>
                    {match.is5to6Players && (
                      <span className="text-[11px] px-2 py-0.5 rounded bg-blue-950 text-blue-300 border border-blue-800 flex items-center gap-1">
                        <Users size={12} />
                        Expansão 5-6
                      </span>
                    )}
                    <span className="text-xs text-stone-400">
                      Meta: <strong className="text-stone-200">{match.targetVP} PV</strong>
                    </span>
                  </div>

                  {/* Actions: Edit & Delete */}
                  <div className="flex items-center gap-2 self-end sm:self-auto">
                    {isDeleting ? (
                      <div className="flex items-center gap-2 bg-red-950 border border-red-800 px-2 py-1 rounded-lg text-xs">
                        <span className="text-red-200">Excluir?</span>
                        <button
                          onClick={() => {
                            onDeleteMatch(match.id);
                            setConfirmDeleteId(null);
                          }}
                          className="px-2 py-0.5 bg-red-600 text-white rounded font-bold hover:bg-red-500"
                        >
                          Sim
                        </button>
                        <button
                          onClick={() => setConfirmDeleteId(null)}
                          className="px-2 py-0.5 bg-stone-800 text-stone-300 rounded hover:bg-stone-700"
                        >
                          Não
                        </button>
                      </div>
                    ) : (
                      <>
                        <button
                          onClick={() => onEditMatch(match)}
                          className="p-1.5 text-stone-400 hover:text-amber-300 hover:bg-stone-800 rounded-lg transition-colors"
                          title="Editar partida"
                        >
                          <Edit size={16} />
                        </button>
                        <button
                          onClick={() => setConfirmDeleteId(match.id)}
                          className="p-1.5 text-stone-400 hover:text-red-400 hover:bg-stone-800 rounded-lg transition-colors"
                          title="Excluir partida"
                        >
                          <Trash2 size={16} />
                        </button>
                      </>
                    )}
                  </div>
                </div>

                {/* Participants Score Strip */}
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2.5">
                  {match.playerResults.map(p => {
                    return (
                      <div
                        key={p.playerId}
                        className={`p-3 rounded-xl border text-center transition-all ${
                          p.isWinner
                            ? 'bg-amber-950/20 border-amber-500/60 shadow-sm'
                            : 'bg-stone-950/60 border-stone-800/80'
                        }`}
                      >
                        <div className="flex items-center justify-center gap-1.5 mb-1.5">
                          <div
                            className="w-3 h-3 rounded-full border border-stone-500 shrink-0"
                            style={{ backgroundColor: p.playerColorHex }}
                          />
                          <span className="text-xs font-semibold text-stone-200 truncate">
                            {p.playerName}
                          </span>
                        </div>

                        <div className="flex items-center justify-center gap-1">
                          <span className="text-xl font-bold font-mono text-stone-100 tabular-nums">
                            {p.vp}
                          </span>
                          <span className="text-xs text-stone-400">PV</span>
                          {p.isWinner && (
                            <Trophy size={14} className="text-amber-400 ml-0.5" />
                          )}
                        </div>

                        <div className="mt-2 pt-2 border-t border-stone-800/60 text-[10px] text-stone-400 space-y-0.5">
                          <div className="flex justify-between">
                            <span>Norm:</span>
                            <span className="font-mono text-stone-300">{p.normalizedVP.toFixed(2)}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>VP%:</span>
                            <span className="font-mono text-amber-300 font-semibold">{p.balancedVPPercent}%</span>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Notes if present */}
                {match.notes && (
                  <div className="p-2.5 bg-stone-950/40 border border-stone-800/60 rounded-xl text-xs text-stone-300">
                    <span className="text-stone-400 font-medium">Observações: </span>
                    {match.notes}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
