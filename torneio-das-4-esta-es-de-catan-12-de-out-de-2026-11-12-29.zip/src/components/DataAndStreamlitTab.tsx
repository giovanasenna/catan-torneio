import React, { useState } from 'react';
import { Download, FileText, Check, Copy, RefreshCw, Database, Terminal } from 'lucide-react';
import { Match } from '../types';
import { exportMatchesToCSV } from '../api';

interface DataAndStreamlitTabProps {
  matches: Match[];
  onResetMatches: () => void;
}

export const DataAndStreamlitTab: React.FC<DataAndStreamlitTabProps> = ({
  matches,
  onResetMatches,
}) => {
  const [copiedPython, setCopiedPython] = useState(false);
  const [copiedSecrets, setCopiedSecrets] = useState(false);
  const [confirmReset, setConfirmReset] = useState(false);

  // Generate CSV download
  const handleDownloadCSV = () => {
    const csvContent = exportMatchesToCSV(matches);
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', 'catan_torneio_4_estacoes.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const copyToClipboard = (text: string, setCopied: (v: boolean) => void) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const pythonStreamlitCode = `# Torneio das 4 Estações de Catan - Streamlit App
# Execute: streamlit run streamlit_app.py
# O código completo e modular também está salvo no arquivo /streamlit_app.py neste repositório!

import streamlit as st
import pandas as pd
import plotly.express as px

st.set_page_config(page_title="Torneio das 4 Estações de Catan", page_icon="🎲", layout="wide")

# Conexão automática com Google Sheets se configurada:
if "gsheets" in st.secrets:
    from streamlit_gsheets import GSheetsConnection
    conn = st.connection("gsheets", type=GSheetsConnection)
    df = conn.read(ttl="5m")
else:
    df = pd.read_csv("catan_torneio_dados.csv")

st.title("🎲 Torneio das 4 Estações de Catan")
st.write("Edição Primavera 2026 - Circuito Oficial")

# Critérios Oficiais:
# 1º: Vitórias (V)
# 2º: Total PV
# 3º: Média do VP% Balanceado: (PV / Total_Mesa) * (N / 4) * 100
`;

  const secretsExample = `# .streamlit/secrets.toml para Google Sheets:
[connections.gsheets]
spreadsheet = "https://docs.google.com/spreadsheets/d/SEU_ID_DA_PLANILHA/edit"
worksheet = "Partidas"
type = "service_account"
project_id = "seu-projeto-gcp"
private_key_id = "..."
private_key = "-----BEGIN PRIVATE KEY-----\\n...\\n-----END PRIVATE KEY-----\\n"
client_email = "service-account@seu-projeto-gcp.iam.gserviceaccount.com"
`;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-stone-900 border border-stone-800 p-5 rounded-2xl flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <Database className="text-amber-400" size={22} />
            <h1 className="text-xl sm:text-2xl font-bold font-serif text-amber-100">
              Arquitetura de Dados & Streamlit Python
            </h1>
          </div>
          <p className="text-xs sm:text-sm text-stone-400 mt-1">
            Exporte dados para Google Sheets ou execute a versão nativa em Python no Streamlit Community Cloud.
          </p>
        </div>

        <button
          onClick={handleDownloadCSV}
          className="flex items-center gap-2 px-4 py-2.5 text-xs font-semibold bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl shadow-sm transition-all shrink-0"
        >
          <Download size={16} />
          <span>Baixar CSV (Excel & Sheets)</span>
        </button>
      </div>

      {/* Grid of Action Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Google Sheets Integration Card */}
        <div className="bg-stone-900 border border-stone-800 p-5 rounded-2xl space-y-4 shadow-sm">
          <div className="flex items-center gap-2">
            <FileText className="text-emerald-400" size={20} />
            <h2 className="text-sm font-bold text-stone-200 uppercase tracking-wide">
              Integração Google Sheets (st.connection)
            </h2>
          </div>
          <p className="text-xs text-stone-300 leading-relaxed">
            Para sincronizar com Google Sheets no Streamlit Community Cloud ou Google Drive:
          </p>
          <ol className="text-xs text-stone-400 space-y-1.5 list-decimal pl-4">
            <li>Crie uma nova planilha no Google Sheets e cole os dados do CSV exportado.</li>
            <li>Compartilhe a planilha com seu e-mail de conta de serviço (Service Account) ou com link público.</li>
            <li>Configure o arquivo <code className="text-amber-300">.streamlit/secrets.toml</code> conforme o modelo abaixo:</li>
          </ol>

          <div className="relative bg-stone-950 p-3 rounded-xl border border-stone-800 text-[11px] font-mono text-stone-300 overflow-x-auto">
            <pre>{secretsExample}</pre>
            <button
              onClick={() => copyToClipboard(secretsExample, setCopiedSecrets)}
              className="absolute top-2 right-2 p-1.5 bg-stone-800 hover:bg-stone-700 text-stone-300 rounded transition-colors"
              title="Copiar configuração"
            >
              {copiedSecrets ? <Check size={14} className="text-emerald-400" /> : <Copy size={14} />}
            </button>
          </div>
        </div>

        {/* Python Streamlit Card */}
        <div className="bg-stone-900 border border-stone-800 p-5 rounded-2xl space-y-4 shadow-sm">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Terminal className="text-amber-400" size={20} />
              <h2 className="text-sm font-bold text-stone-200 uppercase tracking-wide">
                Script Python Streamlit (streamlit_app.py)
              </h2>
            </div>
            <button
              onClick={() => copyToClipboard(pythonStreamlitCode, setCopiedPython)}
              className="flex items-center gap-1 px-2.5 py-1 text-xs bg-stone-800 hover:bg-stone-700 text-stone-200 rounded-lg transition-colors"
            >
              {copiedPython ? <Check size={14} className="text-emerald-400" /> : <Copy size={14} />}
              <span>{copiedPython ? 'Copiado!' : 'Copiar'}</span>
            </button>
          </div>

          <p className="text-xs text-stone-300 leading-relaxed">
            O arquivo modular completo <strong className="text-amber-300">streamlit_app.py</strong> já está gerado na raiz deste projeto com:
          </p>
          <ul className="text-xs text-stone-400 space-y-1 list-disc pl-4">
            <li>Streamlit + Pandas + Plotly com abas interativas</li>
            <li>Formulário de cadastro com metas dos 9 cenários de Navegantes</li>
            <li>Cálculo de PV Normalizado e VP% Balanceado</li>
            <li>Suporte a CSV local e conexão direta com Google Sheets</li>
          </ul>

          <div className="p-3 bg-stone-950 border border-stone-800 rounded-xl text-xs text-stone-300 font-mono">
            <span className="text-stone-500 block mb-1"># Como rodar localmente no terminal:</span>
            pip install streamlit pandas plotly st-gsheets-connection<br />
            streamlit run streamlit_app.py
          </div>
        </div>
      </div>

      {/* Database Maintenance and Reset */}
      <div className="bg-stone-900 border border-stone-800 p-5 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-4 shadow-sm">
        <div>
          <h3 className="text-sm font-bold text-stone-200">
            Reinicialização e Dados de Demonstração
          </h3>
          <p className="text-xs text-stone-400 mt-0.5">
            Restaura o histórico oficial inicial com as partidas de exemplo de Inverno e Primavera.
          </p>
        </div>

        {confirmReset ? (
          <div className="flex items-center gap-2">
            <span className="text-xs text-red-300">Confirmar restauração?</span>
            <button
              onClick={() => {
                onResetMatches();
                setConfirmReset(false);
              }}
              className="px-3 py-1.5 text-xs font-bold bg-red-600 hover:bg-red-500 text-white rounded-lg transition-colors"
            >
              Sim, Restaurar
            </button>
            <button
              onClick={() => setConfirmReset(false)}
              className="px-3 py-1.5 text-xs bg-stone-800 hover:bg-stone-700 text-stone-300 rounded-lg transition-colors"
            >
              Cancelar
            </button>
          </div>
        ) : (
          <button
            onClick={() => setConfirmReset(true)}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-stone-400 hover:text-stone-200 hover:bg-stone-800 border border-stone-700 rounded-xl transition-colors"
          >
            <RefreshCw size={14} />
            <span>Restaurar Dados Iniciais</span>
          </button>
        )}
      </div>
    </div>
  );
};
