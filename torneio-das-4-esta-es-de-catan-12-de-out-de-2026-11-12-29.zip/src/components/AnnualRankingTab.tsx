import React from 'react';
import { Trophy, Globe, Award, Info, Crown } from 'lucide-react';
import { Match } from '../types';
import { calculateAnnualRanking } from '../utils/calculations';
import { SEASONS } from '../constants';

interface AnnualRankingTabProps {
  matches: Match[];
}

export const AnnualRankingTab: React.FC<AnnualRankingTabProps> = ({ matches }) => {
  const annualStandings = calculateAnnualRanking(matches);
  const leader = annualStandings[0];

  return (
    <div className="space-y-6">
      {/* Circuit Header Card */}
      <div className="bg-stone-900 border border-stone-800 p-5 rounded-2xl flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <Globe className="text-amber-400" size={22} />
            <h1 className="text-xl sm:text-2xl font-bold font-serif text-amber-100">
              Circuito Anual das 4 Estações
            </h1>
          </div>
          <p className="text-xs sm:text-sm text-stone-400 mt-1">
            Pontuação consolidada dos 4 jogadores oficiais ao longo de 2026.
          </p>
        </div>

        {/* Season Score Rules Badge */}
        <div className="flex items-center gap-2 bg-stone-950/70 border border-stone-800 px-3.5 py-2 rounded-xl text-xs text-stone-300">
          <Info size={16} className="text-amber-400 shrink-0" />
          <span>
            Fechamento de Estação: <strong>1º = 10 pts</strong> · <strong>2º = 6 pts</strong> · <strong>3º = 3 pts</strong> · <strong>4º = 1 pt</strong>
          </span>
        </div>
      </div>

      {/* Leader Showcase Card */}
      {leader && (
        <div className="bg-gradient-to-r from-amber-950/40 via-stone-900 to-stone-900 border border-amber-500/40 p-5 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-4 shadow-sm">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-300 shadow-inner">
              <Crown size={28} />
            </div>
            <div>
              <span className="text-xs font-bold text-amber-400 uppercase tracking-wider block">
                Líder do Circuito Anual
              </span>
              <h2 className="text-2xl font-bold font-serif text-stone-100">
                {leader.playerName}
              </h2>
              <div className="text-xs text-stone-400 mt-0.5">
                Acumulando {leader.totalAnnualPoints} pontos de campeonato
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="bg-stone-950 border border-stone-800 px-4 py-2 rounded-xl text-center">
              <span className="text-2xl font-bold font-mono text-amber-400 tabular-nums">
                {leader.totalAnnualPoints}
              </span>
              <span className="text-[10px] text-stone-400 uppercase block tracking-wider">
                Pts Anuais
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Annual Matrix Table */}
      <div className="bg-stone-900 border border-stone-800 rounded-2xl shadow-sm overflow-hidden">
        <div className="p-4 border-b border-stone-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Trophy className="text-amber-400" size={18} />
            <h3 className="text-sm font-bold text-stone-200 uppercase tracking-wide">
              Tabela de Pontuação por Estação
            </h3>
          </div>
          <span className="text-xs text-stone-400">
            Apenas Jogadores Oficiais
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm border-collapse">
            <thead>
              <tr className="border-b border-stone-800 bg-stone-950/60 text-stone-400 text-xs uppercase tracking-wider font-semibold">
                <th className="py-3 px-4 w-12 text-center">#</th>
                <th className="py-3 px-4">Jogador</th>
                {SEASONS.map(s => (
                  <th key={s} className="py-3 px-4 text-center">
                    {s} {s === 'Primavera' ? '🌱 (Atual)' : s === 'Inverno' ? '❄️' : s === 'Verão' ? '☀️' : '🍂'}
                  </th>
                ))}
                <th className="py-3 px-6 text-center text-amber-300 font-bold bg-amber-950/20">
                  Total Anual
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-800/60 text-stone-200">
              {annualStandings.map(row => {
                return (
                  <tr key={row.playerId} className="hover:bg-stone-800/40 transition-colors">
                    <td className="py-4 px-4 text-center font-bold font-mono text-stone-400 tabular-nums">
                      {row.rank === 1 ? '🥇' : row.rank === 2 ? '🥈' : row.rank === 3 ? '🥉' : '4º'}
                    </td>

                    <td className="py-4 px-4">
                      <div className="flex items-center gap-2.5">
                        <div
                          className="w-3.5 h-3.5 rounded-full border border-stone-500 shrink-0"
                          style={{ backgroundColor: row.colorHex }}
                        />
                        <span className="font-semibold text-stone-100">
                          {row.playerName}
                        </span>
                      </div>
                    </td>

                    {/* Season Columns */}
                    {SEASONS.map(s => {
                      const pts = row.pointsBySeason[s];
                      const pos = row.seasonRanks[s];
                      return (
                        <td key={s} className="py-4 px-4 text-center">
                          {pos !== null ? (
                            <div className="inline-flex flex-col items-center">
                              <span className="font-mono font-bold text-stone-100 tabular-nums">
                                {pts} pts
                              </span>
                              <span className="text-[10px] text-stone-400">
                                ({pos}º lugar)
                              </span>
                            </div>
                          ) : (
                            <span className="text-stone-600 font-mono">-</span>
                          )}
                        </td>
                      );
                    })}

                    {/* Total Anual */}
                    <td className="py-4 px-6 text-center bg-amber-950/20">
                      <span className="font-mono font-bold text-lg text-amber-400 tabular-nums">
                        {row.totalAnnualPoints} pts
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Rules Footer Callout */}
      <div className="p-4 bg-stone-950/60 border border-stone-800 rounded-xl text-xs text-stone-400 space-y-1">
        <p className="font-semibold text-stone-300">
          Nota sobre participantes convidados no Circuito Anual:
        </p>
        <p>
          Os visitantes cadastrados jogam normalmente e suas vitórias ficam registradas nas partidas e no histórico geral. Porém, a pontuação de campeonato do Circuito Anual (10, 6, 3, 1 pts) é concedida aos 4 jogadores oficiais (Jhonata, Rodrigo, Giovana, Zhang) conforme a colocação relativa apurada no encerramento de cada estação.
        </p>
      </div>
    </div>
  );
};
