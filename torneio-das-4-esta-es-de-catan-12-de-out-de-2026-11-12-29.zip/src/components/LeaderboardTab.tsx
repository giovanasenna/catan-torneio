import React, { useState } from 'react';
import { Trophy, HelpCircle, Award, Users, ChevronDown, ChevronUp } from 'lucide-react';
import { Match, PlayerStanding, Season } from '../types';
import { CURRENT_SEASON, SEASONS } from '../constants';
import { calculateStandings } from '../utils/calculations';

interface LeaderboardTabProps {
  matches: Match[];
  onOpenMatchModal: () => void;
}

export const LeaderboardTab: React.FC<LeaderboardTabProps> = ({ matches, onOpenMatchModal }) => {
  const [selectedSeason, setSelectedSeason] = useState<Season | 'all'>(CURRENT_SEASON);
  const [includeVisitors, setIncludeVisitors] = useState<boolean>(false);
  const [showMathHelp, setShowMathHelp] = useState<boolean>(false);
  const [expandedMobilePlayerId, setExpandedMobilePlayerId] = useState<string | null>(null);

  const standings = calculateStandings(matches, selectedSeason, includeVisitors);
  const seasonMatches = selectedSeason === 'all'
    ? matches
    : matches.filter(m => m.season === selectedSeason);

  const toggleExpandMobile = (id: string) => {
    setExpandedMobilePlayerId(prev => (prev === id ? null : id));
  };

  return (
    <div className="space-y-5">
      {/* Top Controls Banner */}
      <div className="bg-stone-900 border border-stone-800 p-4 sm:p-5 rounded-2xl shadow-sm space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg sm:text-2xl font-bold font-serif text-amber-100">
                Classificação da Estação
              </h1>
              {selectedSeason === CURRENT_SEASON && (
                <span className="text-[10px] sm:text-xs font-semibold px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800">
                  Ativa
                </span>
              )}
            </div>
            <p className="text-xs sm:text-sm text-stone-400 mt-0.5">
              {seasonMatches.length} partidas disputadas {selectedSeason !== 'all' ? `no ${selectedSeason}` : 'no circuito'}.
            </p>
          </div>

          <div className="flex items-center gap-3 text-xs">
            <label className="flex items-center gap-1.5 cursor-pointer text-stone-300 hover:text-stone-100 select-none bg-stone-950/60 px-2.5 py-1.5 rounded-lg border border-stone-800">
              <input
                type="checkbox"
                checked={includeVisitors}
                onChange={e => setIncludeVisitors(e.target.checked)}
                className="rounded border-stone-700 bg-stone-950 text-amber-500 focus:ring-0"
              />
              <Users size={13} className="text-stone-400" />
              <span>Visitantes</span>
            </label>

            <button
              onClick={() => setShowMathHelp(!showMathHelp)}
              className="text-stone-400 hover:text-amber-300 flex items-center gap-1 transition-colors px-2 py-1"
            >
              <HelpCircle size={14} />
              <span className="hidden sm:inline">Critérios</span>
            </button>
          </div>
        </div>

        {/* Horizontal Season Pills (scrollable on mobile) */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
          {SEASONS.map(season => {
            const isCurrent = season === selectedSeason;
            return (
              <button
                key={season}
                onClick={() => setSelectedSeason(season)}
                className={`px-3.5 py-1.5 text-xs font-medium rounded-xl transition-all whitespace-nowrap min-h-[36px] flex items-center justify-center ${
                  isCurrent
                    ? 'bg-amber-400 text-stone-950 font-bold shadow-sm'
                    : 'bg-stone-950/80 text-stone-300 hover:bg-stone-800 border border-stone-800'
                }`}
              >
                {season} {season === CURRENT_SEASON ? '🌱' : ''}
              </button>
            );
          })}
          <button
            onClick={() => setSelectedSeason('all')}
            className={`px-3.5 py-1.5 text-xs font-medium rounded-xl transition-all whitespace-nowrap min-h-[36px] flex items-center justify-center ${
              selectedSeason === 'all'
                ? 'bg-amber-400 text-stone-950 font-bold shadow-sm'
                : 'bg-stone-950/80 text-stone-300 hover:bg-stone-800 border border-stone-800'
            }`}
          >
            Todas
          </button>
        </div>
      </div>

      {/* Math Help Accordion */}
      {showMathHelp && (
        <div className="p-4 bg-stone-950/90 border border-amber-900/60 rounded-2xl text-xs text-stone-300 space-y-2 animate-fade-in">
          <div className="font-semibold text-amber-300 flex items-center gap-1.5">
            <Trophy size={14} />
            <span>Critérios Oficiais de Desempate:</span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-1">
            <div className="bg-stone-900 p-2.5 rounded-xl border border-stone-800">
              <span className="font-bold text-stone-100 block">1º Vitórias (V)</span>
              Total de vitórias conquistadas na estação.
            </div>
            <div className="bg-stone-900 p-2.5 rounded-xl border border-stone-800">
              <span className="font-bold text-stone-100 block">2º PV Total Acumulado</span>
              Soma de todos os PVs conquistados.
            </div>
            <div className="bg-stone-900 p-2.5 rounded-xl border border-stone-800">
              <span className="font-bold text-stone-100 block">3º Média do VP% Balanceado</span>
              Equaliza mesas de 3 a 6 jogadores para o padrão de 4.
            </div>
          </div>
        </div>
      )}

      {/* MOBILE-FIRST CARD VIEW (< md screens) */}
      <div className="block md:hidden space-y-3">
        {standings.length === 0 ? (
          <div className="bg-stone-900 border border-stone-800 rounded-2xl p-6 text-center text-xs text-stone-400">
            Nenhuma partida registrada nesta estação.{' '}
            <button
              onClick={onOpenMatchModal}
              className="text-amber-400 underline font-semibold block mt-1"
            >
              Registrar partida agora
            </button>
          </div>
        ) : (
          standings.map(row => {
            const isExpanded = expandedMobilePlayerId === row.playerId;
            const rankMedal =
              row.rank === 1 ? '🥇 1º' : row.rank === 2 ? '🥈 2º' : row.rank === 3 ? '🥉 3º' : `${row.rank}º`;

            return (
              <div
                key={row.playerId}
                className={`bg-stone-900 border rounded-2xl overflow-hidden transition-all shadow-sm ${
                  row.rank === 1 ? 'border-amber-500/60 bg-gradient-to-b from-amber-950/20 to-stone-900' : 'border-stone-800'
                }`}
              >
                {/* Main Card Header & Summary */}
                <div
                  onClick={() => toggleExpandMobile(row.playerId)}
                  className="p-4 cursor-pointer select-none"
                >
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2.5 min-w-0">
                      <span className="font-mono font-bold text-xs px-2 py-0.5 rounded-lg bg-stone-950 text-stone-300 border border-stone-800 shrink-0">
                        {rankMedal}
                      </span>
                      <div
                        className="w-4 h-4 rounded-full border border-stone-500 shrink-0 shadow-sm"
                        style={{ backgroundColor: row.playerColorHex }}
                      />
                      <span className="font-bold text-base text-stone-100 truncate font-serif">
                        {row.playerName}
                      </span>
                      {!row.isOfficial && (
                        <span className="text-[10px] text-stone-400 bg-stone-800 px-1.5 py-0.5 rounded shrink-0">
                          Visitante
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-1 text-stone-400 text-xs">
                      {isExpanded ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
                    </div>
                  </div>

                  {/* 3 Core Big Numbers for Mobile Glance */}
                  <div className="grid grid-cols-3 gap-2 bg-stone-950/60 p-3 rounded-xl border border-stone-800/80 text-center">
                    <div>
                      <span className="text-xl font-bold font-mono text-amber-400 block tabular-nums">
                        {row.wins}
                      </span>
                      <span className="text-[10px] uppercase font-semibold text-stone-400 tracking-wider">
                        Vitórias (V)
                      </span>
                    </div>

                    <div>
                      <span className="text-xl font-bold font-mono text-stone-100 block tabular-nums">
                        {row.totalVP}
                      </span>
                      <span className="text-[10px] uppercase font-semibold text-stone-400 tracking-wider">
                        PV Total
                      </span>
                    </div>

                    <div>
                      <span className="text-xl font-bold font-mono text-emerald-400 block tabular-nums">
                        {row.avgBalancedVPPercent.toFixed(1)}%
                      </span>
                      <span className="text-[10px] uppercase font-semibold text-stone-400 tracking-wider">
                        Média VP%
                      </span>
                    </div>
                  </div>
                </div>

                {/* Expanded Details Drawer */}
                {isExpanded && (
                  <div className="px-4 pb-4 pt-1 border-t border-stone-800/80 bg-stone-950/30 text-xs space-y-2 animate-fade-in">
                    <div className="grid grid-cols-2 gap-2 text-stone-300 pt-2">
                      <div className="bg-stone-900/80 p-2.5 rounded-lg border border-stone-800">
                        <span className="text-stone-400 block text-[11px]">Partidas Jogadas</span>
                        <span className="font-mono font-bold text-stone-100 text-sm">{row.matchesPlayed}</span>
                      </div>
                      <div className="bg-stone-900/80 p-2.5 rounded-lg border border-stone-800">
                        <span className="text-stone-400 block text-[11px]">Taxa de Vitória (%)</span>
                        <span className="font-mono font-bold text-amber-400 text-sm">{row.winRate.toFixed(1)}%</span>
                      </div>
                      <div className="bg-stone-900/80 p-2.5 rounded-lg border border-stone-800">
                        <span className="text-stone-400 block text-[11px]">PV Médio / Partida</span>
                        <span className="font-mono font-bold text-stone-100 text-sm">{row.avgVP.toFixed(2)}</span>
                      </div>
                      <div className="bg-stone-900/80 p-2.5 rounded-lg border border-stone-800">
                        <span className="text-stone-400 block text-[11px]">Maior Pontuação</span>
                        <span className="font-mono font-bold text-stone-100 text-sm">{row.highestVP} PV</span>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* DESKTOP TABLE VIEW (>= md screens) */}
      <div className="hidden md:block bg-stone-900 border border-stone-800 rounded-2xl shadow-sm overflow-hidden">
        <div className="p-4 border-b border-stone-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Award className="text-amber-400" size={18} />
            <h2 className="text-sm font-bold text-stone-200 uppercase tracking-wide">
              Tabela de Classificação Oficial
            </h2>
          </div>
          <span className="text-xs text-stone-400">
            Ordenado por Vitórias &gt; PV Total &gt; Média VP% Balanceado
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm border-collapse">
            <thead>
              <tr className="border-b border-stone-800 bg-stone-950/60 text-stone-400 text-xs uppercase tracking-wider font-semibold">
                <th className="py-3 px-4 w-12 text-center">#</th>
                <th className="py-3 px-4">Jogador</th>
                <th className="py-3 px-3 text-center">Partidas</th>
                <th className="py-3 px-3 text-center text-amber-300">Vitórias (V)</th>
                <th className="py-3 px-3 text-center text-stone-200">Total PV</th>
                <th className="py-3 px-3 text-center text-emerald-300">Média VP%</th>
                <th className="py-3 px-3 text-center">Taxa V%</th>
                <th className="py-3 px-3 text-center">PV Médio</th>
                <th className="py-3 px-4 text-center">Maior PV</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-800/60 text-stone-200">
              {standings.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-8 text-center text-stone-400">
                    Nenhuma partida registrada nesta estação.{' '}
                    <button
                      onClick={onOpenMatchModal}
                      className="text-amber-400 hover:underline font-semibold"
                    >
                      Registrar primeira partida
                    </button>
                  </td>
                </tr>
              ) : (
                standings.map(row => (
                  <tr key={row.playerId} className="hover:bg-stone-800/40 transition-colors">
                    <td className="py-3.5 px-4 text-center font-bold font-mono text-stone-400 tabular-nums">
                      {row.rank === 1 ? '🥇' : row.rank === 2 ? '🥈' : row.rank === 3 ? '🥉' : row.rank}
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="flex items-center gap-2.5">
                        <div
                          className="w-3.5 h-3.5 rounded-full border border-stone-500 shrink-0"
                          style={{ backgroundColor: row.playerColorHex }}
                        />
                        <span className="font-semibold text-stone-100 font-serif">
                          {row.playerName}
                        </span>
                        {!row.isOfficial && (
                          <span className="text-[10px] text-stone-400 bg-stone-800 px-1.5 py-0.5 rounded">
                            Visitante
                          </span>
                        )}
                      </div>
                    </td>

                    <td className="py-3.5 px-3 text-center font-mono tabular-nums text-stone-300">
                      {row.matchesPlayed}
                    </td>

                    <td className="py-3.5 px-3 text-center font-mono font-bold text-amber-400 tabular-nums">
                      {row.wins}
                    </td>

                    <td className="py-3.5 px-3 text-center font-mono font-bold text-stone-100 tabular-nums">
                      {row.totalVP}
                    </td>

                    <td className="py-3.5 px-3 text-center font-mono font-semibold text-emerald-400 tabular-nums">
                      {row.avgBalancedVPPercent.toFixed(2)}%
                    </td>

                    <td className="py-3.5 px-3 text-center font-mono tabular-nums text-stone-300">
                      {row.winRate.toFixed(1)}%
                    </td>

                    <td className="py-3.5 px-3 text-center font-mono tabular-nums text-stone-400">
                      {row.avgVP.toFixed(2)}
                    </td>

                    <td className="py-3.5 px-4 text-center font-mono tabular-nums text-stone-300">
                      {row.highestVP}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
