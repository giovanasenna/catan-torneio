import { ANNUAL_POINTS_TABLE, OFFICIAL_PLAYERS, SEASONS } from '../constants';
import { AnnualStanding, Match, PlayerStanding, Season } from '../types';

/**
 * Calculates Normalized VP (PV do jogador / Meta de PV)
 */
export function calculateNormalizedVP(vp: number, targetVP: number): number {
  if (targetVP <= 0) return 0;
  return Number((vp / targetVP).toFixed(3));
}

/**
 * Calculates VP% Balanceado:
 * (PV do Jogador / Soma total de PV da mesa) * (Número de Jogadores na Mesa / 4) * 100
 */
export function calculateBalancedVPPercent(
  playerVP: number,
  totalTableVP: number,
  numPlayers: number
): number {
  if (totalTableVP <= 0) return 0;
  const rawRatio = playerVP / totalTableVP;
  const balanceFactor = numPlayers / 4;
  return Number((rawRatio * balanceFactor * 100).toFixed(2));
}

/**
 * Computes the leaderboard standings for a given season or across all seasons.
 * Ranking Criteria:
 * 1º: Vitórias (desc)
 * 2º: Total PV (desc)
 * 3º: Média de VP% Balanceado (desc)
 */
export function calculateStandings(
  matches: Match[],
  seasonFilter?: Season | 'all',
  includeVisitors: boolean = false
): PlayerStanding[] {
  const filteredMatches = seasonFilter && seasonFilter !== 'all'
    ? matches.filter(m => m.season === seasonFilter)
    : matches;

  // Aggregate stats per player
  const playerMap = new Map<string, {
    playerId: string;
    playerName: string;
    isOfficial: boolean;
    playerColorHex: string;
    matchesPlayed: number;
    wins: number;
    totalVP: number;
    sumBalancedVPPercent: number;
    highestVP: number;
  }>();

  // Pre-seed official players so they always appear in standings even if 0 matches
  if (!includeVisitors || seasonFilter !== 'all') {
    for (const official of OFFICIAL_PLAYERS) {
      playerMap.set(official.id, {
        playerId: official.id,
        playerName: official.name,
        isOfficial: true,
        playerColorHex: official.colorHex,
        matchesPlayed: 0,
        wins: 0,
        totalVP: 0,
        sumBalancedVPPercent: 0,
        highestVP: 0,
      });
    }
  }

  // Iterate over matches
  for (const match of filteredMatches) {
    for (const res of match.playerResults) {
      if (!includeVisitors && !res.isOfficial) {
        continue;
      }

      let p = playerMap.get(res.playerId);
      if (!p) {
        p = {
          playerId: res.playerId,
          playerName: res.playerName,
          isOfficial: res.isOfficial,
          playerColorHex: res.playerColorHex,
          matchesPlayed: 0,
          wins: 0,
          totalVP: 0,
          sumBalancedVPPercent: 0,
          highestVP: 0,
        };
        playerMap.set(res.playerId, p);
      }

      p.matchesPlayed += 1;
      if (res.isWinner) {
        p.wins += 1;
      }
      p.totalVP += res.vp;
      p.sumBalancedVPPercent += res.balancedVPPercent;
      if (res.vp > p.highestVP) {
        p.highestVP = res.vp;
      }
    }
  }

  const list: PlayerStanding[] = Array.from(playerMap.values()).map(p => {
    const avgVP = p.matchesPlayed > 0 ? Number((p.totalVP / p.matchesPlayed).toFixed(2)) : 0;
    const winRate = p.matchesPlayed > 0 ? Number(((p.wins / p.matchesPlayed) * 100).toFixed(1)) : 0;
    const avgBalancedVPPercent = p.matchesPlayed > 0
      ? Number((p.sumBalancedVPPercent / p.matchesPlayed).toFixed(2))
      : 0;

    return {
      playerId: p.playerId,
      playerName: p.playerName,
      isOfficial: p.isOfficial,
      playerColorHex: p.playerColorHex,
      matchesPlayed: p.matchesPlayed,
      wins: p.wins,
      totalVP: p.totalVP,
      avgVP,
      winRate,
      avgBalancedVPPercent,
      highestVP: p.highestVP,
      rank: 1, // Will be set after sorting
    };
  });

  // Sort strictly by official criteria:
  // 1º: Vitórias (desc)
  // 2º: Total PV (desc)
  // 3º: Média de VP% Balanceado (desc)
  list.sort((a, b) => {
    if (b.wins !== a.wins) return b.wins - a.wins;
    if (b.totalVP !== a.totalVP) return b.totalVP - a.totalVP;
    return b.avgBalancedVPPercent - a.avgBalancedVPPercent;
  });

  // Assign ranks
  list.forEach((item, index) => {
    item.rank = index + 1;
  });

  return list;
}

/**
 * Computes Annual Ranking across the 4 Seasons for the 4 Official Players.
 * Rules:
 * Each season ranks the 4 official players.
 * 1º lugar: 10 pts
 * 2º lugar: 6 pts
 * 3º lugar: 3 pts
 * 4º lugar: 1 pt
 * (If a season has no matches yet, 0 pts are assigned for that season).
 */
export function calculateAnnualRanking(matches: Match[]): AnnualStanding[] {
  // Store annual points for each official player
  const result: Record<string, AnnualStanding> = {};

  for (const p of OFFICIAL_PLAYERS) {
    result[p.id] = {
      playerId: p.id,
      playerName: p.name,
      colorHex: p.colorHex,
      pointsBySeason: {
        Inverno: 0,
        Primavera: 0,
        Verão: 0,
        Outono: 0,
      },
      seasonRanks: {
        Inverno: null,
        Primavera: null,
        Verão: null,
        Outono: null,
      },
      totalAnnualPoints: 0,
      rank: 1,
    };
  }

  // Calculate points for each season
  for (const season of SEASONS) {
    const seasonMatches = matches.filter(m => m.season === season);
    if (seasonMatches.length === 0) continue;

    // Get standings of official players for this season
    const seasonStandings = calculateStandings(matches, season, false);

    seasonStandings.forEach((standing, index) => {
      const pos = index + 1;
      const pts = ANNUAL_POINTS_TABLE[pos] || 0;
      if (result[standing.playerId]) {
        result[standing.playerId].pointsBySeason[season] = pts;
        result[standing.playerId].seasonRanks[season] = pos;
        result[standing.playerId].totalAnnualPoints += pts;
      }
    });
  }

  const annualList = Object.values(result);

  // Sort by Total Annual Points (desc), then by highest season finishes
  annualList.sort((a, b) => {
    if (b.totalAnnualPoints !== a.totalAnnualPoints) {
      return b.totalAnnualPoints - a.totalAnnualPoints;
    }
    // Tiebreaker: compare season finishes
    return 0;
  });

  annualList.forEach((item, idx) => {
    item.rank = idx + 1;
  });

  return annualList;
}
